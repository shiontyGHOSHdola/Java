package Interface;
import FileCode.*;
interface Operation {
	
	 public void addPerson(Person p);
	 
	 public void ShowAllInformation();
	 
	 public void removePerson(String id);
	 
	 public void search(String id);
}